-- phpMyAdmin SQL Dump
-- version 4.3.11.1
--
-- Host: localhost:3306
-- Generation Time: aug 03, 2020 at 08:20 AM
-- Server version: 5.5.42
-- PHP Version: 5.4.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `student_n`
--


CREATE TABLE IF NOT EXISTS `1_102015` (
  `srl` int(11) NOT NULL,
  `att_date` date DEFAULT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `1_102015` (`srl`, `att_date`, `in_time`, `out_time`) VALUES
(1, '2020-8-3', '19:59:25', '19:59:44'),
(2, '2020-8-3', '14:51:48', '14:52:06');

CREATE TABLE IF NOT EXISTS `1_attn_mo` (
  `serial` int(8) NOT NULL,
  `mon_yr` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `1_attn_mo` (`serial`, `mon_yr`) VALUES
(0, 102015);

CREATE TABLE IF NOT EXISTS `2_102015` (
  `srl` int(11) NOT NULL,
  `att_date` date DEFAULT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `2_102015` (`srl`, `att_date`, `in_time`, `out_time`) VALUES
(1, '2015-10-28', '14:53:52', '14:54:11');

CREATE TABLE IF NOT EXISTS `2_attn_mo` (
  `serial` int(5) NOT NULL,
  `mon_yr` varchar(6) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


INSERT INTO `2_attn_mo` (`serial`, `mon_yr`) VALUES
(1, '102015');

CREATE TABLE IF NOT EXISTS `student_dat` (
  `stu_id` int(8) NOT NULL,
  `stu_name` varchar(25) DEFAULT NULL,
  `stu_pass` varchar(25) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `contact` int(12) DEFAULT NULL,
  `stu_add` varchar(25) DEFAULT NULL,
  `join_date` date DEFAULT NULL,
  `rfid_num` varchar(25) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `student_dat` (`stu_id`, `stu_name`, `stu_pass`, `email`, `contact`, `stu_add`, `join_date`, `rfid_num`) VALUES
(1, 'sanjeev', 'testitem1', 'sanju12@gmail.com', 8825588261, 'san,123', '1999-5-17', ' 85 29 e0 74'),
(2, 'xyz', 'xyz', 'xyz', 123, 'qqq''', '2020-1-28', ' 36 8f 2d 3b');

ALTER TABLE `1_102015`
  ADD PRIMARY KEY (`srl`);

ALTER TABLE `2_102015`
  ADD PRIMARY KEY (`srl`);

ALTER TABLE `2_attn_mo`
  ADD PRIMARY KEY (`serial`);

ALTER TABLE `student_dat`
  ADD PRIMARY KEY (`stu_id`);

ALTER TABLE `1_102015`
  MODIFY `srl` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;

ALTER TABLE `2_102015`
  MODIFY `srl` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;

ALTER TABLE `2_attn_mo`
  MODIFY `serial` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;

ALTER TABLE `student_dat`
  MODIFY `stu_id` int(8) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;

