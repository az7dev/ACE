import mysql.connector, filer

global www
www = filer.p
mydb=mysql.connector.connect(host="localhost", user=www[0], password=www[1], port = 3306, database = "attadmin")
mycursor=mydb.cursor()
def main(sname, sclass, usertype, cursobj = mycursor):

	# Import tkinter as tk 
	import tkinter as tk
	from tkinter import messagebox 


	# creating a new tkinter window 
	master = tk.Tk() 

	# assigning a title 
	master.title("ACE_MARKSHEET_" + sname) 

	# specifying geomtery for window size 
	master.geometry("700x250")

	# declaring objects for entering data 
	examname = tk.Entry(master) 
	
	#register = tk.Entry(master) 
	#rollno = tk.Entry(master) 
	#photo=PhotoImage(file='skyandsea.png')
    #Label(root, image=photo).place(relwidth = 1, relheight = 1)
	chem = tk.Entry(master) 
	phy = tk.Entry(master) 
	math = tk.Entry(master) 
	csci = tk.Entry(master)
	eng = tk.Entry(master)
	tk.Label(master, text="Total Marks").grid(row=8, column=3)
	

	def show():
		exam = examname.get()
		mycursor.execute('select chemistry, physics, maths, computer_science, english, total from smarks where examname = %s and sname = %s', (exam, sname))#the select command for marks-display
		sublis = mycursor.fetchone()
		try:
			chem.insert(0, sublis[0])
			phy.insert(0, sublis[1])
			math.insert(0, sublis[2])
			csci.insert(0, sublis[3])
			eng.insert(0, sublis[4])
			
			tk.Label(master, text="Total Marks: " + str(sublis[5])).grid(row=8, column=3)
		except Exception as e:
			print(e)
			messagebox.showinfo('error;', 'marks for ' + exam + ' have not been entered')
		
		
	def markupdate():
		
		e = examname.get()
		ch = chem.get()
		p = phy.get()
		m = math.get()
		cs = csci.get()
		en = eng.get()
		print(ch, p, m, cs, en)
		try:
			mycursor.execute('insert into smarks values(%s, %s, %s, %s, %s, %s, %s, %s, %s);', (sname, sclass, e, int(p), int(ch), int(m), int(cs), int(en), sum([int(p), int(ch), int(m), int(cs), int(en)])))
			mydb.commit()
			messagebox.showinfo('information', 'marks inserted.')
			e = examname.set('')
			ch = chem.delete(0, END)
			p = phy.delete(0, END)
			m = math.delete(0, END)
			cs = csci.delete(0, END)
			en = eng.delete(0, END)
		except Exception as e:
			print('woops!\n', e)
		

	# label to enter name 
	tk.Label(master, text="exam name:").grid(row=0, column=0) 

	# label for registration number 
	#tk.Label(master, text="Reg.No").grid(row=0, column=3) 

	# label for roll Number 
	#tk.Label(master, text="Roll.No").grid(row=1, column=0) 

	# labels for serial numbers 
	tk.Label(master, text="Srl.No").grid(row=2, column=0) 
	tk.Label(master, text="1").grid(row=3, column=0) 
	tk.Label(master, text="2").grid(row=4, column=0) 
	tk.Label(master, text="3").grid(row=5, column=0) 
	tk.Label(master, text="4").grid(row=6, column=0) 
	tk.Label(master, text="5").grid(row=7, column=0)


	# labels for subject codes 
	tk.Label(master, text="Subject").grid(row=2, column=1) 
	tk.Label(master, text="CHM").grid(row=3, column=1) 
	tk.Label(master, text="PHY").grid(row=4, column=1) 
	tk.Label(master, text="MAT").grid(row=5, column=1) 
	tk.Label(master, text="CSC").grid(row=6, column=1)
	tk.Label(master, text="ENG").grid(row=7, column=1) 

		
	# label for grades 
	tk.Label(master, text="MARKS").grid(row=2, column=2) 
	chem.grid(row=3, column=2) 
	phy.grid(row=4, column=2) 
	math.grid(row=5, column=2) 
	csci.grid(row=6, column=2) 
	eng.grid(row=7, column=2)


	# taking entries of name, register, roll number respectively 
	examname=tk.Entry(master) 
	#register=tk.Entry(master) 
	#rollno=tk.Entry(master) 

	# organizing them in the grid 
	examname.grid(row=0, column=1) 
	#register.grid(row=0, column=4) 
	#rollno.grid(row=1, column=1) 
	if usertype == 'TEACHER':
		button1=tk.Button(master, text="submit", bg="green", command=markupdate) 
		button1.grid(row=8, column=1) 
	button2=tk.Button(master, text="show", bg="blue", command=show,font = 'Assassin$.ttf') 
	button2.grid(row=0, column=2) 
	 

	master.mainloop() 



