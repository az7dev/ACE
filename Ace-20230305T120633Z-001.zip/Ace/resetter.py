import mysql.connector, pickle, filer
global www
www = filer.p
mydb=mysql.connector.connect(host="localhost", user=www[0], password=www[1], port = 3306, database = "attadmin")
mycursor=mydb.cursor()

with open('tfile.txt', 'w') as tf:
    tf.write('zero')
    print('teacher file overwritten.')
with open('Afile.txt', 'w') as af:
    af.write('zero')
    print('admin file overwritten.')

print('you may exit after 5 seconds...')
mycursor.execute('drop database attadmin;')
print('goobye')
mydb.commit()
mycursor.close()
mydb.close()
print('deleted all tables...')


with open('Ace.dat', 'wb') as ace:
    pickle.dump({}, ace)
    print('ace file overwritten.')
print('resetting complete')

