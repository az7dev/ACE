import pickle
#module used to get pre-stored sql password, etc
f = open('D:\Ace\Ace.dat', 'rb')
p = pickle.load(f)

U = p[0]
P = p[1]
f.close()