#module for user interface 
#

import mysql.connector as sql
from time import sleep

###***read the afile.txt ; based on its contents, decide whether to launch setup, or to run ACE. ***###
decide = open('D:\Ace\Afile.txt', 'r')
choice = decide.read()
decide.close()

if choice == 'one':      
   import pygame, sys, Teacher, datetime, Admin, Awindow, attdate, filer, Student, markwindow
   
   www = filer.p
   
   connection = sql.connect(user = www[0], password = www[1], host = '127.0.0.1', port = 3306, database = 'attadmin')
   firsttime = True

   char, page = '', 'loginpage'
   bcol = (0, 255, 0)
   from pygame.locals import *
   pygame.init()
   #print()
   font = pygame.font.Font('freesansbold.ttf', 32)
   f1 = pygame.font.Font('freesansbold.ttf', 22)
   f2 = pygame.font.Font('freesansbold.ttf', 18)
   algerian = pygame.font.Font('ALGER.ttf', 18)
   algerian32 = pygame.font.Font('ALGER.ttf', 32)
   tango = pygame.font.Font('tango.ttf', 22)
   monterey = pygame.font.Font('MontereyFLF.ttf', 32)
   assassin = pygame.font.Font('Assassin$.ttf', 32, italic = True)
   assassin18 = pygame.font.Font('Assassin$.ttf', 18, italic = True)
   vertigo = pygame.font.Font('VertigoFLF.ttf', 32, italic = True, bold = True)
   bradhitc = pygame.font.Font('BRADHITC.ttf', 22, bold = True)
   mistral = pygame.font.Font('MISTRAL.ttf', 32)
   al = {8 : '', 97 : 'a', 98 : 'b', 99 : 'c', 100 : 'd', 101 : 'e', 102 : 'f', 103 : 'g', 104 : 'h', 105 : 'i', 106 : 'j', 107 : 'k', 108 : 'l', 109 : 'm', 110 : 'n', 111 : 'o', 112 : 'p', 113 : 'q', 114 : 'r', 115 : 's', 116 : 't', 117 : 'u', 118 : 'v', 119 : 'w', 120 : 'x', 121 : 'y', 122 : 'z'}
   wind = pygame.display.set_mode((900, 900))
   icon = pygame.image.load('D:\Ace\ice0.jpg')
   pygame.display.set_caption('A.C.E.')
   pygame.display.set_icon(icon)

   def txtdisp(dtxt, txtloc, f = font, tcol = (0, 0, 255), bcol = (0, 255, 0)):#for
      txt = f.render(dtxt, True, tcol, bcol)
      txtcoord = txt.get_rect()
      
      txtcoord.center = txtloc
      wind.blit(txt, txtcoord)
      return (txtloc[0] - (txtcoord[2]//2), txtloc[0] + (txtcoord[2]//2), txtloc[1] - (txtcoord[3]//2), txtloc[1] + (txtcoord[3]//2))
      

   def accreq(ekey, char):
      txtdisp('please enter your name;', (450, 150), f = monterey)
      txtdisp('ATTENDANCE CONTROLLER EXTRAORDINAIRE', (450, 75), f = assassin)
      pic = pygame.image.load('ce0.png')
      wind.blit(pic, (350, 180))

      if char != '' :
         if ekey == 8:
            
            tem = list(char)
         
            tem.pop()
            char = ''
            for i in tem:
               char += i
            txtdisp(char,(450, 450), f = monterey)
            
            return char
         else:
            char += al[ekey]
            txtdisp(char, (450, 450), f = monterey)
            return char
         
      else:   
         char += al[ekey]
         txtdisp(char, (450, 450), f = monterey)
         
         return char

   def pwdreq(ekey, char):
      txtdisp('please enter your access password;', (450, 200), f = vertigo)
      txtdisp('ATTENDANCE CONTROLLER EXTRAORDINAIRE', (450, 75), f = assassin)

      if char != '' :
         if ekey == 8:
            
            tem = list(char)
         
            tem.pop()
            char = ''
            for i in tem:
               char += i
            txtdisp('*' * len(char),(450, 450), f = vertigo)
            
            return char
         else:
            char += al[ekey]
            txtdisp('*' * len(char), (450, 450), f = vertigo)
            return char
         
      else:   
         char += al[ekey]
         txtdisp('*', (450, 450), f = vertigo)
         
         return char

   def accden():
      txtdisp('sorry...no.\ntry once more', (450, 200), f = assassin)
      sleep(3)
      wind.fill((0, 0, 0))
      txtdisp('please enter your name;', (450, 200), f = monterey)
      return 'loginpage'

   def button(page, event, dtxt, txtloc, bcol = (0, 255, 0),  f = monterey, tcol = (0, 0, 255)):
      pointlist = txtdisp(dtxt, txtloc, f, tcol, bcol)
      if event.type == pygame.MOUSEBUTTONDOWN:
         if pygame.mouse.get_pos()[0] in range(pointlist[0], pointlist[1]) and pygame.mouse.get_pos()[1] in range(pointlist[2], pointlist[3]):
            if pygame.BUTTON_LEFT:
               
               txtdisp(dtxt, txtloc, f, tcol, bcol = (0, 0, 0))
               page = dtxt
               
               return page
            else:
               return page
         else:
            return page
      return page



   def updbutton(toddate, connection, event, dtxt, Sname, txtloc, bcol = (0, 255, 0),  f = monterey, tcol = (0, 0, 255)):
      
      pointlist = txtdisp(dtxt, txtloc, f, tcol, bcol)
      if event.type == pygame.MOUSEBUTTONDOWN:
         if pygame.mouse.get_pos()[0] in range(pointlist[0], pointlist[1]) and pygame.mouse.get_pos()[1] in range(pointlist[2], pointlist[3]):
            if pygame.BUTTON_LEFT:
               wind.fill((220, 220, 20))
               txtdisp(dtxt, txtloc, f, tcol, bcol = (0, 0, 0))
               Teacher.upd(connection,Tname = nm, dtxt = dtxt, Sname = Sname, toddate = toddate)
               
               
   def widgetbutton(event, dtxt, txtloc, widget, bcol = (0, 255, 0),  f = monterey, tcol = (0, 0, 255)):
      pointlist = txtdisp(dtxt, txtloc, f, tcol, bcol)
      
      if event.type == pygame.MOUSEBUTTONDOWN:
         if pygame.mouse.get_pos()[0] in range(pointlist[0], pointlist[1]) and pygame.mouse.get_pos()[1] in range(pointlist[2], pointlist[3]):
            if pygame.BUTTON_LEFT:
               txtdisp(dtxt, txtloc, f, tcol, bcol = (0, 0, 0))
               widget = int(dtxt)
               return widget
            return widget
         return widget
      return widget 


   def viewstudentdata(page, event):
      wind.fill((220, 220, 20))
      att = 'check/update attendance'
      page = button(page, event, att, (450, 200), bcol, f = assassin)
      

      return page
                     
   def accgtd(event, user):
      sleep(1)
      txtdisp('access granted to ' + nm + "'s files ", (450, 90), f = mistral)
      txtdisp(user + " access", (450, 50), f = mistral)
      return 'tmenu'
      
   def Tmenu(page, event):
      studata = 'view student data'
      
      yrdata = 'manage student marks' 
      lo = 'loginpage'
      page = button(page, event, studata, (450, 150), bcol, f = bradhitc)
      pic = pygame.image.load('ce0.png')
      wind.blit(pic, (350, 180))
      page = button(page, event, yrdata, (450, 450), bcol, f = bradhitc)
      page = button(page, event, lo, (450, 550), bcol = (0, 0, 0), f = monterey)
      if page == 'loginpage':
         wind.fill((0, 0, 0))
         txtdisp('please enter your name;', (450, 200), f = monterey)
      return page

   def Amenu(page, event):
      page = button(page, event, 'Manage Staff', (450, 150), bcol, f = tango)
      page = button(page, event, 'loginpage', (450, 350), bcol = (0, 0, 0), f = monterey)
      page = button(page, event, 'reset app.', (450, 500), bcol, f = assassin)
      if page == 'loginpage':
         wind.fill((0, 0, 0))
         txtdisp('please enter your name;', (450, 200), f = monterey)
      if page == 'reset app.':
         wind.fill((255, 0, 0))
      return page

   def Smenu(page, event, nm):
      txtdisp("Student Access", (450, 50), f = vertigo)
      txtdisp("WELCOME! " + nm, (450, 200), f = mistral)
      pic = pygame.image.load('ce0.png')
      wind.blit(pic, (350, 250))
      page = button(page, event, 'Manage your account', (450, 490), bcol, f = tango)
      page = button(page, event, 'loginpage', (450, 550), bcol = (0, 0, 0), f = monterey)
      if page == 'loginpage':
         wind.fill((0, 0, 0))
         txtdisp('please enter your name;', (450, 200), monterey)
      return page


   def namedisplay(toddate, widget, user, page, namelist, event, bcol = (0, 255, 0),  f = font, tcol = (0, 0, 255)):
      connection.commit()

      q = 0
      
      txtdisp('STUDENT', (72, 25), f = assassin18, tcol = (0, 0, 0))
      txtdisp('ATTENDANCE', (197, 25), f = assassin18)
      txtdisp(str(toddate), (447, 25), f = f2)
      for i in namelist:
         txtdisp(i[0], (72, 50 + q*50), f = tango, tcol = (0, 0, 0))
         txtdisp(i[1], (197, 50 + q*50), f = tango)
         
         updbutton(toddate, connection, event, 'present', i[0], (322, 50 + q*50), f = algerian, bcol = (250, 150, 100))
         updbutton(toddate, connection, event, 'absent', i[0], (447, 50 + q*50), f = algerian, bcol = (250, 150, 100))

         q += 1
      page = button(page, event, 'loginpage', (450, 550), bcol, f = assassin)
      page = button(page, event, 'select date', (450, 650), bcol, f = mistral)
      page = button(page, event, 'tmenu', (650, 550), bcol, f = assassin18)
      pic = pygame.image.load('ce0.png')
      wind.blit(pic, (650, 50))
      
      widget = widgetbutton(event, str(widget + 1) , (465, 485), widget, bcol = (0, 255, 0),  f = algerian32, tcol = (0, 0, 0))
      if widget > 0:
         widget = widgetbutton(event, str(widget - 1), (20, 485), widget, bcol = (0, 255, 0),  f = algerian32, tcol = (0, 0, 0))
      if page == 'loginpage':
         wind.fill((0, 0, 0))
         txtdisp('please enter your name;', (450, 200), f = monterey)

      elif page == 'tmenu':
         wind.fill((255, 0, 0))
         page = accgtd(event, user)
         
      return (page, widget)
   def marksfn(event, widget, page, toddate, display_list = []):
      display_list = []
      pic = pygame.image.load('ce0.png')
      wind.blit(pic, (650, 50))
      for i in Teacher.nl(connection, Tname = nm, toddate = toddate)[widget]:
         
         display_list += [i[0]]
      widget = widgetbutton(event, str(widget + 1) , (465, 485), widget, bcol = (0, 255, 0),  f = algerian, tcol = (0, 0, 0))
      if widget > 0:
         widget = widgetbutton(event, str(widget - 1), (20, 485), widget, bcol = (0, 255, 0),  f = algerian, tcol = (0, 0, 0))
      
      markpage, q = '', 0
      ###markpage is the variable which will store the name of a student;
      txtdisp('STUDENTS', (250, 25), f = assassin, tcol = (0, 0, 0))
      
      for k in display_list:
         markpage = button(markpage, event, k, (250, 50 + q), f = algerian)
         q += 50
      if bool(markpage):
         markwindow.main(markpage, Teacher.main(connection, Tname = nm)[0], usertype = 'TEACHER')
      page = 'manage student marks'
      page = button(page, event, 'loginpage', (450, 550), bcol = (0, 0, 0), f = monterey)
      page = button(page, event, 'tmenu', (650, 550), bcol, f = bradhitc)

      return [page, widget]


   


   

   txtdisp('please enter your name;', (450, 200), f = monterey)
   while True:#main loop which executes everything
      
      for event in pygame.event.get():
         
         if event.type == QUIT:
            pygame.quit()
            sys.exit()

         elif page == 'loginpage' and event.type == pygame.KEYDOWN:

            
            if event.key != 13:
               
               if event.key in al.keys():
                  wind.fill((0, 0, 0))
                  char = accreq(event.key, char)
               else: 
                  continue

               continue
   
            elif event.key == 13:
               
               
               if char in Teacher.main(connection, Tname = char)[4]:
                  wind.fill((0, 0, 0))
                  txtdisp('please enter your access password;', (450, 200), f = f1)
                  nm = char
                  char = ''
                  page = 'Tpwdpage'

               elif char in Admin.getAlist():
                  wind.fill((255, 255, 255))
                  txtdisp('please enter your access password;', (450, 200), f = f1)
                  nm = char
                  char = ''
                  page = 'Apwdpage'
               elif char in Student.getSlist():
                  wind.fill((100, 100, 100))
                  txtdisp('WELCOME! ' + char, (450, 200), f = f1)
                  nm = char
                  char = ''
                  page = 'Smenu'


               else:

                  #wind.fill((0, 0, 0))
                  
                  char = ''
                  page = 'accden'
   
         elif page == 'Apwdpage' and event.type == pygame.KEYDOWN:


            if event.key != 13:
               if event.key in al.keys():
                  wind.fill((255, 255, 255))
                  char = pwdreq(event.key, char)
               else:
                  continue

            elif event.key == 13:
               if char == Admin.getApass(nm):
   
                  wind.fill((255, 0, 0))
                  char = ''
                  user = 'ADMIN'
                  sleep(1)
                  txtdisp('access granted to ' + nm + "'s files ", (450, 90))
                  txtdisp(user + " access", (450, 50), f = f2)
                  page = 'Amenu'
               else:
                  wind.fill((0, 0, 0))
                  char = ''
                  page = 'accden'

         elif page == 'Smenu':
            page = Smenu(page, event, nm)
         
         elif page == 'reset app.':
            check = Admin.getApass(nm)
            import getpass
            con = getpass.getpass(prompt = 'requesting confirmation to reset A.C.E.;\ndear admin, please enter your ACE password: ')
            if con == check:
               import resetter
               wind.fill((200, 200, 200))
               txtdisp("closing A.C.E.", (450, 450), f = vertigo, bcol= (255, 0, 0))
               sleep(5)
               pygame.quit()
               sys.exit()
            else:
               print('authentication denied')
               sys.exit()
               pygame.quit()

         elif page == 'Tpwdpage' and event.type == pygame.KEYDOWN:
            
            if event.key != 13:
               if event.key in al.keys():
                  wind.fill((0, 0, 0))
                  char = pwdreq(event.key, char)
               else:
                  continue

            elif event.key == 13:
               if char == Teacher.main(connection, Tname = nm)[3]:
                  cur = connection.cursor()
                  cur.execute("select visit from Teacher where Tname = %s", (nm, ))
                  if cur.fetchone()[0] == 0:
                     wind.fill((0, 0, 0))
                     sleep(3)
                     Teacher.classrender(connection, Tname = nm)
                     connection.close()
                     pygame.quit()
                     sys.exit()
                  else:
                     wind.fill((255, 0, 0))
                     char = ''
                     user = 'TEACHER'
                     page = accgtd(event, user)
               else:
                  #wind.fill((0, 0, 0))
                  char = ''
                  page = 'accden'


         elif page == 'accden':
            page = accden()

         elif page == 'Manage your account':
            wind.fill((100, 100, 100))
            import Sinput
            Sinput.fn(nm, Teacher.main(connection, Tname = nm)[0])
            page = 'Smenu' 
            
         elif page == 'Amenu':
            page = Amenu(page, event)

         elif page == 'tmenu':
            
            page = Tmenu(page, event)
            if page == 'loginpage':
               wind.fill((0, 0, 0))
               txtdisp('please enter your name;', (450, 200))
         
         elif page == 'Manage Staff':
            Awindow.Afun()
            page = 'Amenu'
         elif page == 'select date':
            toddate = attdate.main()
            wind.fill((220, 220, 20))
            page = 'check/update attendance'
               
         elif page == 'view student data':

            page = viewstudentdata(page, event)
            if page == 'check/update attendance':
               wind.fill((220, 220, 20))
            
         elif page == 'manage student marks': ###in progress
            wind.fill((220, 220, 20))
            markpage, q = '', 0
            if firsttime:
               widget = 0
               toddate = datetime.date.today()
               
            firsttime = False
            #widget = 0#work here;
            ###markpage is the variable which will store the name of a student;
            variable = marksfn(event, widget, page, toddate)
            page, widget = variable[0], variable[1]
            if page == 'loginpage':
               wind.fill((0, 0, 0))
               txtdisp('please enter your name;', (450, 200))
               firsttime = True

            elif page == 'tmenu':
               wind.fill((255, 0, 0))
               page = accgtd(event, user)
               firsttime = True
         
         elif page == 'check/update attendance':
            
            if firsttime:
               widget = 0
               
               toddate = attdate.main()
 
            namelist = Teacher.nl(connection, Tname = nm, toddate = toddate)
            
            
            if widget < len(namelist):
               wind.fill((220, 220, 20))
               pw = namedisplay(toddate, widget, user, page, namelist[widget], event)
            else:
               wind.fill((220, 220, 20))
               pw = namedisplay(toddate, widget - 1, user, page, namelist[widget - 1], event)
          
            page = pw[0]
            widget = pw[1]
            firsttime = False
            pass


      pygame.display.update()

else:
   import setuper
   decide = open('D:\Ace\Afile.txt', 'w')
   decide.write('one')
   decide.close()
   print('all ready. pls login again.')
   sleep(5)



