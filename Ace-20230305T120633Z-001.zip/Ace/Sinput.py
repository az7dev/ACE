import mysql.connector as a
from datetime import datetime
import markwindow, filer
www = filer.p
def fn(name, sclass):
    dbConn=a.connect(host = "127.0.0.1",user = www[0],password = www[1],database = "attadmin")or die("couldn't connect to DB")
    print('hi there, ', name, '!\n')
    lis = ['yes', 'y', 'yeah', 'yup', 'okay', 'ok', 'alright']
    cursor=dbConn.cursor()
    cursor.execute("Select * from student;")
    message = ''

    try:
        result=cursor.fetchall()
        
        for i in result:
            print(i[0] + str(bool(i[3])))
            print(i)
            if i[0] == name and not bool(i[3]):
                nn = i[0]
                message = 'proceeding'
                break
            else:
                message = "User already exists lol\n" 
                continue
    except Exception as e:
        print("User already exists\n", e)
    if message == 'proceeding':
        
        stu_email=input("Enter your email: ")
        stu_con=input("Enter Contact Number: ")
        stu_rfid= input("Enter given rfid number: ")
        stu_rfid=" "+stu_rfid
        print(message)
       
        cursor.execute("update student set Semail = %s, Srfid = %s where Sname = %s;",(stu_email,stu_rfid, nn))
        print('inserted')
    ans = input('proceed to view marks? :  ')
    if ans.lower() in lis:
        markwindow.main(name, sclass, 'STUDENT')
        proceed = ''
    
    dbConn.commit()
    cursor.close()