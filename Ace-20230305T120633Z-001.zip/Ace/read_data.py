import serial
import MySQLdb
from datetime import datetime
dbConn=MySQLdb.connect("127.0.0.1","root","mobile","student_n")or die("couldn't connect to DB") 

device="\\.\COM3" 
while True:
    cursor=dbConn.cursor()
    try:
        print "Trying...",device
        arduino=serial.Serial(device, 9600)
        a=0
    try:
        data=""
        data=arduino.readline();
        data=data.strip();
        data=" "+data
        arduino.flush()
        try:
            cursor.execute("select stu_id, stu_name from student_dat where rfid_num=(%s)",(data))
            result=cursor.fetchone()
            if result:
                stul_id=result[0]
                stul_id=str(stul_id)
            x=int(cursor.rowcount)
            if x!=0:
                tstu="select * from %s where mon_yr="%(stul_id+"_attn_mo")
                tstu+="(%s)"
                
                cursor.execute(tstu,(str(datetime.now().month)+str(datetime.now().year)))
                result=cursor.fetchone()
                if result:
                    mont_yr=str(result[1])
                x=int(cursor.rowcount)
                if x!=0:
                    month="%02d"%datetime.now().month
                    day="%02d"%datetime.now().day
                    hour="%02d"%datetime.now().hour
                    minute="%02d"%datetime.now().minute
                    second="%02d"%datetime.now().second
                    tstu="show tables like '%s'"%(stul_id+"_"+mont_yr);
                    cursor.execute(tstu)
                    tabch=cursor.fetchone()
                    
                    y=int(cursor.rowcount)
                    if y==0:
                        tstu="create table %s (srl int(11) AUTO_INCREMENT NOT NULL PRIMARY KEY, att_date date, in_time time,out_time time)"%(stul_id+"_"+mont_yr)
                        cursor.execute(tstu)
                        dbConn.commit()
                    tstu="select * from %s where att_date='%s'"%(stul_id+"_"+mont_yr,str(datetime.now().year)+"-"+month+"-"+day)
                    cursor.execute(tstu)
                    result=cursor.fetchone()
                    x=int(cursor.rowcount)
                    if x!=0:
                        if result[2] is not None:
                            if result[3] is None:
                                tstu="update %s set out_time='%s' where att_date='%s'"%(stul_id+"_"+mont_yr,hour+":"+minute+":"+second,str(datetime.now().year)+"-"+month+"-"+day)
                                cursor.execute(tstu)
                                print "Out Time Marked"
                                arduino.write("Out Marked")
                            else:
                                print "Entry exists"
                                arduino.write("Entry exists")
                    else:
                        tstu="insert into %s (att_date,in_time) values "%(stul_id+"_"+mont_yr)
                        tstu+="(%s,%s)"
                        cursor.execute(tstu,(str(datetime.now().year)+"-"+month+"-"+day,hour+":"+minute+":"+second))
                        print "Attendance Marked"
                        arduino.write("Attn. marked")
                else:
                    tstu="insert into %s(mon_yr) values "%(stul_id+"_attn_mo")
                    tstu+="(%s)"
                    cursor.execute(tstu,(str(datetime.now().month)+str(datetime.now().year)))
                    print "Scan again"
                    arduino.write("Scan Again")
            else:
                print "User doesnt exist"
                arduino.write("User not found!")
            dbConn.commit()
            arduino.flush()
            time.sleep(4)
            
            cursor.close()
        except MySQLdb.IntegrityError:
            print "failed to fetch data"
            a=0
        finally:
            cursor.close()
    except:
        a=0

        
    
