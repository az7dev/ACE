sig = 'rep'
import mysql.connector as sql
import getpass
#accepting setup-input from admin
while sig != 'go':
    try:
 
        username = input('hello, user; please enter your name:\n>>>')
        Apwd = getpass.getpass(prompt = 'please set a password(atleast 7 characters) which you will use to access the application:\n>>>')
        sqluser = input('please enter your mysql username:\n>>>')
        sqlpass = getpass.getpass(prompt= 'enter your mysqlpassword, please:\n>>>')
        Tpwd = getpass.getpass(prompt = 'configure a password for teacher-access:\n>>>')

        conn = sql.connect(user = sqluser, password = sqlpass, host = '127.0.0.1', port = 3306)
        
        if conn.is_connected() and username != '' and len(Tpwd) >= 7 and len(Apwd) >= 7 :
            sig = 'go'
        elif not conn.is_connected():
            print('sql username - sql password mismatch\n***dear user, pls check your sql password***\n')
            while sig != 'go':
                sqluser = input('please enter your mysql username:\n>>>')
                sqlpass = getpass.getpass(prompt= 'please enter correct mysql password:\n>>>')
                conn = sql.connect(user = sqluser, password = sqlpass, host = '127.0.0.1', port = 3306)
                if conn.is_connected():
                    sig = 'go'
                else:
                    print('wrong sql password for the username')
            
        elif username == '':
            print('***dear user, pls enter your name!***')
            while sig != 'go':
                username = input('please enter your name:\n>>>')
                if username != '':
                    sig = 'go'
                else:
                    pass
    
                
        elif len(Apwd) < 7:
            print('your password is too short :(')
            while sig != 'go':
                Apwd = getpass.getpass(prompt='please enter a password with atleast 7 characters')
                if len(Apwd) < 7:
                    print('too short. pls enter a longer password')
                else:
                    sig = 'go'
            
        
        elif len(Tpwd) < 7:
            print('the password for Teachers is too short :(')
            while sig != 'go':
                Tpwd = getpass.getpass('please enter a teacher-password with atleast 7 characters')
                if len(Tpwd) < 7:
                    print('too short. pls enter a longer teacher-password')
                else:
                    sig = 'go'

    except Exception as e:
        print(e)
        print('sorry :( \nsomething went wrong. please try again')
        sig = 'rep'
        continue

    if conn.is_connected() and username != '' and len(Tpwd) >= 7 and len(Apwd) >= 7 :
        sig = 'go'
    else:
        sig = 'rep'
        print('sorry you will have to do it all over again.')

curs = conn.cursor()
print('setting up.....')

import pickle
f = open('D:\Ace\Ace.dat', 'wb')
a = [sqluser, sqlpass, Tpwd]
pickle.dump(a, f)
f.close()

for i in ['create database attadmin', 'use attadmin']:
    curs.execute(i)
curs.execute('create table admin(Aname varchar(20), status varchar(15), pass varchar(70))')
curs.execute('insert into admin values(%s, %s, %s)', (username, 'admin', Apwd))
curs.execute("create table student(Sname varchar(20), Sclass varchar(10), Semail varchar(25), Srfid varchar(20));")
curs.execute("create table teacher(Tname varchar(20), Tclass varchar(15), TID varchar(12), password varchar(15), visit int);")
curs.execute("create table smarks(Sname varchar(20), Sclass varchar(10), examname varchar(20), physics int, chemistry int, maths int, computer_science int, english int, total int);")
conn.commit()
print('password inserted.')

sig = 'rep'
while sig != 'go':
    while sig != 'go':
        
        NoC = int(input("please enter the number of classes for which you would like to use this application:\n>>>"))
    
        if NoC > 0:
            print("okay. enter the ", NoC, " class(es):\n>>>")
            sig = 'go'
        elif NoC == 0:
            print('please enter a finite no of classes...')
            sig = 'rep'
            continue
    Clist = []
    sig = 'rep'
    for r in range(1, NoC + 1):
        while sig != 'go':
            x = input(str(r) + ". ")
            if x != '':
                Clist += [x]
            else:
                print('sorry, cant accept blank class names. try again.\n')
                continue
            sig = 'go'
        sig = 'rep'
    sig = 'go'

print('preparing to create tables for the classes...')
for c in Clist:
    curs.execute('create table ' + c + '(Sname varchar(25), toddate date, attendance varchar(12), Srfid varchar(20));')
print('done. you are free to go.')
