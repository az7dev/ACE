import mysql.connector as sql
import filer
www = filer.p
connection = sql.connect(user = www[0], password = www[1], host = '127.0.0.1', port = 3306, database = 'attadmin')
curs = connection.cursor()

def getSlist():
    curs.execute('select Sname from Student;')
    x = curs.fetchall()
    ret = []
    for i in x:
        ret += i
    return ret

def getSclass(Sname):
    curs.execute('select Sclass from Student where Sname = %s;', (Sname, ))
    return curs.fetchone()[0]

def getrfid(Sname):
    curs.execute('select Srfid from Student where Sname = %s;', (Sname, ))
    return curs.fetchone()

def rfid_update(Srfid, Sname, Sclass):
    curs.execute('update Student set Srfid = %s where Sname = %s;', (Srfid, Sname))
    connection.commit()
    selcomm = 'update ' + Sclass + ' set Srfid = %s where Sname = %s;'
    
    curs.execute(selcomm, (Srfid, Sname))
    connection.commit()