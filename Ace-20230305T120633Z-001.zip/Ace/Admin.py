import mysql.connector as sql
import filer
www = filer.p
connection = sql.connect(user = www[0], password = www[1], host = '127.0.0.1', port = 3306, database = 'attadmin')
curs = connection.cursor()
def getAlist():
    curs.execute('select Aname from Admin;')
    
    return curs.fetchone()

def getApass(Aname):
    curs.execute('select pass from Admin where Aname = %s', (Aname, ))
    return curs.fetchone()[0]

