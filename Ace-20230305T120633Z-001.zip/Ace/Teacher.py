###module for managing user access to database tables, (especially the teacher table)
dt1 = {6 : (30, 30), 7 : (31, 31), 8 : (31, 31), 9 : (30, 30), 10 : (31, 31), 11 : (30, 30), 12 : (31, 31), 1 : (31, 31), 2 : (28, 29), 3 : (31, 31), 4 : (30, 30), 5 : (31, 31)}
import mysql.connector as sql
import datetime, filer
Tlist = ['mrx']
Tpass = 'password'
tab = 'employee'
www = filer.p
class Tmain:

   def __init__(self, connection, Tname, Sname, dtxt, toddate):
      self.toddate = toddate
      self.conn = connection
      self.Tname = Tname
      self.Sname = Sname
      self.dtxt = dtxt

   def getTpass(self):
      T = self.Tname
      curs = self.conn.cursor()   
      curs.execute('select password from Teacher where Tname = "{}"'.format(T))
      mno = curs.fetchone()
      if mno != None:
         return mno[0]
      else:
         return ''
      self.conn.commit()

   def getTlist(self):
      Tlist = []
      curs = self.conn.cursor()   
      curs.execute('select Tname from Teacher')
      mno = curs.fetchall()
      if mno != None: 
         for i in mno:
            Tlist += [i[0]]
         print(Tlist)
         return Tlist
      else:
         return ''
      self.conn.commit()

      
      
   def getclass(self): #function to get teacher's class
      T = self.Tname
      curs = self.conn.cursor()   
      curs.execute('select Tclass from Teacher where Tname = "{}"'.format(T))
      mno = curs.fetchone()
      if mno != None:
         return mno[0]
      else:
         return ''
      
      self.conn.commit()

   def getstulist(self):  # to get the list of students belonging to a specific class
      
      stulist = []
      curs = self.conn.cursor()
      T = self.Tname
      curs.execute('select Tclass from Teacher where Tname = "{}"'.format(T))
      pqr = curs.fetchone()
      if pqr != None:
         C = pqr[0] 
      elif pqr == None:
         C = ''
      curs.execute('select Sname from Student where Sclass = "{}"'.format(C))
      mno = curs.fetchall()
      if mno != None:
         for i in mno:
            stulist += [i[0]]
         return stulist
      else:
         return ''

   def Updater(self): #updating attendance into database
      
      curs = self.conn.cursor()
      T = self.Tname
      print("OK", T, "computer")
      curs.execute('select Tclass from Teacher where Tname = "{}"'.format(T))
      pqr = curs.fetchone()
      if pqr != None:
         C = pqr[0] 
      elif pqr == None:
         C = ''
      selcomm = 'update ' + C + ' set attendance = %s where Sname = %s and toddate = %s;'
      
      curs.execute(selcomm, (self.dtxt, self.Sname, self.toddate))
      self.conn.commit()
      pass

   def getnamelist(self):
      count, lis1, lis2 = 0, [], []
      curs = self.conn.cursor()
      T = self.Tname
      curs.execute('select Tclass from Teacher where Tname = "{}"'.format(T))
      pqr = curs.fetchone()
      if pqr != None:
         C = pqr[0] 
      elif pqr == None:
         C = ''
      selcomm = 'select Sname, attendance from ' + C + ' where toddate = "{}"' 
      
      curs.execute(selcomm.format(self.toddate))
      r = curs.fetchall()
      cou = 0
      
      for k in range(0, len(r), 5):
        
         while cou < 5:
            
            if count < len(r):
               lis1 += [r[count]]
            else:
               break
            count += 1
            cou += 1
         
         cou = 0
         
         lis2 += [lis1]
         lis1 = []
   
      return lis2

   def stuentry(self):
      applist = []
      curs = self.conn.cursor()
      Tname = self.Tname
      print("welcome, " + Tname + '!!')
      cS = int(input("please enter the strength of your class."))
      print("okay. enter the ", cS, " name(s)")
      for r in range(1, cS + 1):
         x = input(str(r) + ". ")
         applist += [x]

      
      print("okay. student names collected.\nplease wait for sometime....")
      
      curs.execute('select Tclass from Teacher where Tname = "{}"'.format(Tname))
      C = curs.fetchone()[0] 
      for s in applist:
         curs.execute('insert into Student values(%s, %s, %s, %s);', (s, C, ' ', ' '))
      selcomm = "insert into " + C + " values(%s, %s, %s, %s)"
      ct = 0
      dlim = 0
      
      yr = str(self.toddate).split(sep = '-')[0]
      for m in dt1:
         
         if int(yr) % 4 == 0:
            dlim = 1
         if m == 1:
            yr = str(int(str(self.toddate).split(sep = '-')[0]) + 1)

         D = dt1[m]
         
         for d in range(1, D[dlim] + 1): 
            for i in range(len(applist)):
               curs.execute(selcomm, (applist[i], yr + "-" + str(m) + "-" + str(d) , "unentered", ' '))
               self.conn.commit()
               ct += 1
         dlim = 0
      print(ct, " rows have been rendered ready for updation.")
      curs.execute("update Teacher set visit = 1 where Tname = %s", (Tname, ))
      self.conn.commit()
      print('all okay. you may login again and use the application!')
      from time import sleep
      sleep(10)

      
      
   #def getmarks(s):
   #   mrklist = {}
   #   selcomm = 'select stname, marks from ' + tab
   #   curs.execute(selcomm)
   #   lis = curs.fetchall()
   #   for i in lis:
   #      mrklist[i[0][0]] = i[1][0]
   #   return mrklist
      
   #def getatt(day, month):
   #   attlist = {}
   #   selcomm = 'select stname, att from StudentAttendance' + tab
   #   curs.execute(selcomm)
   #   lis = curs.fetchall()
   #   for i in lis:
   #      attlist[i[0][0]] = i[1][0]
   #   return attlist

connection = sql.connect(user = www[0], password = www[1], host = '127.0.0.1', port = 3306, database = 'attadmin')
def main(connection, Tname = '', Sname = '', dtxt = 'unentered', toddate = datetime.date.today()):
   mainobj = Tmain(connection, Tname, Sname, dtxt, toddate)
   
   one = mainobj.getclass()
   two = mainobj.getstulist()
   
   four = mainobj.getTpass()
   five = mainobj.getTlist()
   return [one, two, 0, four, five]

def upd(connection, Tname = '', Sname = '', dtxt = 'unentered', toddate = datetime.date.today()):
   mainobj = Tmain(connection, Tname, Sname, dtxt, toddate)
   mainobj.Updater()

def nl(connection, toddate, Tname = '', Sname = '', dtxt = 'unentered'):
   
   mainobj = Tmain(connection, Tname, Sname, dtxt, toddate)
   three = mainobj.getnamelist()
   return three

def classrender(connection, Tname = '', Sname = '', dtxt = 'unentered', toddate = datetime.date.today()):
   mainobj = Tmain(connection, Tname, Sname, dtxt, toddate)
   mainobj.stuentry()

connection.close()


