from tkinter.ttk import *
from tkinter import *
import mysql.connector, filer
from tkinter import messagebox
global www
www = filer.p
def Afun():
    
    mydb=mysql.connector.connect(host="localhost", user=www[0], password=www[1], port = 3306, database = "attadmin")
    mycursor=mydb.cursor()


    def Register():
        
        TID=e3.get()
        dbst_id=""
        Select="select TID from Teacher;" 
        mycursor.execute(Select)
        result=mycursor.fetchall()
        signal = 'go'
            
        if(TID in result):
            messagebox.askokcancel("Information","That ID Already exists")
            signal = ''
        if signal == 'go':    
            
            Insert="Insert into Teacher(Tname, Tclass, TID, password, visit) values(%s, %s, %s, %s, 0)"
            Tname=e1.get()
            Tclass = e2.get()
            if(Tname != '' and Tclass != ''):
                    
                Values=(Tname, Tclass, TID, www[2])
                mycursor.execute(Insert,Values)
                mydb.commit()
                messagebox.askokcancel("Information","Record inserted")
                e1.delete(0, END)
                e2.delete(0, END)
                e3.delete(0, END)
            elif (Tname == "" or TID == ''):
                messagebox.askokcancel("Information", "Some fields are left blank. pls try again :)")

    def ShowRecord():
        TID=e3.get()
        dbst_id=""
        Select="select TID from Teacher"

        mycursor.execute(Select)
        result1=mycursor.fetchall()
        print(result1)
        
        Select1="select * from Teacher where TID = %s;"
        mycursor.execute(Select1, (TID, ))
        result2=mycursor.fetchall()
        Tname = ''
        Tclass = ''
        
        if(TID in result1[0]):
            for i in result2:
                Tname = i[0]
                Tclass = i[1]
                e1.insert(0,Tname)
                e2.insert(0, Tclass)
                
        else:
            messagebox.askokcancel("Information","No Record exists")
    def Delete():
        TID=e3.get()
        if TID != '':
             
            mycursor.execute("delete from Teacher where TID = %s", (TID, ))
            messagebox.showinfo("Information","Record Deleted")
            mydb.commit()
        elif TID == '':
            messagebox.showinfo("Information","Teacher ID unentered...")
        
        
        e3.delete(0, END)
        
    def Update():
        Tname=e1.get()
        Tclass=e2.get()
        TID=e3.get()
        if TID != '':
            if Tname != '':
                mycursor.execute("update Teacher set Tname = %s where TID = %s", (Tname, TID))
                mydb.commit()
                messagebox.showinfo("Info","Record Updated: " + Tname)
            if Tclass != '':
                mycursor.execute('update Teacher set Tclass = %s where TID = %s', (Tclass, TID))
                mydb.commit()
                messagebox.showinfo("Info","Record Updated: " + Tclass)
            if Tname == '' and Tclass == '':
                messagebox.showinfo("Info","Please enter atleast one record to be updated;")
        elif TID == '':
                messagebox.showinfo("Information","Teacher ID Unentered...")
        
        
    def Showall():
        class A(Frame):
            def __init__(self, parent):
                Frame.__init__(self, parent)
                self.CreateUI()
                self.LoadTable()
                self.grid(sticky=(N, S, W, E))
                parent.grid_rowconfigure(0, weight=1)
                parent.grid_columnconfigure(0, weight=1)
            def CreateUI(self):
                tv= Treeview(self)
                tv['columns']=("Teacher's Name", "Teacher's class", "Teacher's ID")
                
                tv.heading('#0',text='Teacher Name',anchor='center')
                tv.column('#0',anchor='center')
                tv.heading('#1', text='Teacher Class', anchor='center')
                tv.column('#1', anchor='center')
                tv.heading('#2', text='Teacher ID', anchor='center')
                tv.column('#2', anchor='center')
              
                tv.grid(sticky=(N,S,W,E))
                self.treeview = tv
                self.grid_rowconfigure(0,weight=1)
                self.grid_columnconfigure(0,weight=1)
            def LoadTable(self):
                Select="Select * from Teacher"
                mycursor.execute(Select)
                result=mycursor.fetchall()
                Tname = ''
                Tclass = ''
                TID = ''
                for i in result:
                    Tname = i[0]
                    Tclass = i[1]
                    TID=i[2]
                    
                    self.treeview.insert("",'end',text= Tname ,values=(Tclass, TID))
        root=Tk()
        root.title("Overview Psubject")
        A(root)
    def Clear():
        e1.delete(0, END)
        e2.delete(0, END)
        e3.delete(0, END)
    def help():
        messagebox.showinfo('HELP', "to Register staff members, enter info into the columns, and press register\nDelete: enter the ID of the teacher whose record needs to be deleted, and press delete.\nShow Record: enter the ID which you want to read, and press Show record.\nShow All: just click Show All to view all records\nClear: click clear to clear all the fields.\nTo Update: enter the Teacher ID of the entry which needs to be updated, and enter the new name/class.")

    root=Tk()
    root.title("Staff Data")
    root.geometry("1200x700")
    root.configure(background = 'black')

    photo=PhotoImage(file='bpic.png')
    
    Label(root,image=photo).place(relwidth = 1, relheight = 1)
    label1=Label(root,text="Teacher Name",width=20,height=2,bg="pink").grid(row=0,column=0)
    label2=Label(root,text="Teacher's class",width=20,height=2,bg="pink").grid(row=1,column=0)
    label3=Label(root,text="Teacher's ID",width=20,height=2,bg="pink").grid(row=2,column=0)

    e1=Entry(root,width=30,borderwidth=8)
    e1.grid(row=0,column=1)
    e2=Entry(root,width=30,borderwidth=8)
    e2.grid(row=1,column=1)
    e3=Entry(root,width=30,borderwidth=8)
    e3.grid(row=2,column=1)
        
    button1=Button(root,text="Register",width=10,height=2,command=Register).grid(row=7,column=0)
    button2=Button(root,text="Delete",width=10,height=2,command=Delete).grid(row=7,column=1)
    button3=Button(root,text="Update",width=10,height=2,command=Update).grid(row=7,column=3)
    button4=Button(root,text="Show record",width=10,height=2,command=ShowRecord).grid(row=7,column=5)
    button5=Button(root,text="Show All",width=10,height=2,command=Showall).grid(row=7,column=7)
    button6=Button(root,text="Clear",width=10,height=2,command=Clear).grid(row=7,column=9)
    button7 = Button(root,text="HELP",width=10,height=2,command=help).grid(row=6,column=9)

    root.mainloop()
