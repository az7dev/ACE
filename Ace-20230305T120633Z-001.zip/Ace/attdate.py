from tkcalendar import *
from tkinter import *
def main():
    root = Tk()
    calwind = Calendar(root, selectmode = 'day', date_pattern = 'y-mm-dd')
    calwind.pack(pady = 20)
    labe = Label(root, text = '')
    labe.pack(pady = 10)
    def getdate():
        global D
        D = calwind.get_date()
        
        labe.config(text = 'selected date : ' + D)
       
        
    b = Button(root, text = 'select', command = getdate)
    b.pack(pady = 20)
    root.mainloop()
    
    return D
    